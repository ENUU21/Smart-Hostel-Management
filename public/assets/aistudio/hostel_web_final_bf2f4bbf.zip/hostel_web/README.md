# Smart Hostel Management System — Web Edition

A Django web application. This is the web version of the Smart Hostel
Management System, carrying over all the improvements from the Tkinter
desktop edition: merged pages, smart search, modal forms, accordion notices,
complaint status workflow, password eye icon, input validation, and room
capacity 4.

## 🚀 Quick start

```bash
# 1. Install Django
pip install -r requirements.txt

# 2. Run migrations
python manage.py migrate

# 3. Seed the database with sample data
python seed.py

# 4. Start the development server
python manage.py runserver

# 5. Open http://127.0.0.1:8000/ in your browser
```

## 🔐 Default logins

| Role    | Username    | Password    |
|---------|-------------|-------------|
| Warden  | `manash`    | `manash123` |
| Student | `pradip123` | `pradip123` |

## 📦 Seed data

- 7 rooms (A01–A07, capacity 4 each)
- 5 students
- 4 complaints
- 2 notices
- 1 warden

## 🧰 Tech stack

| Layer              | Technology                                    |
|--------------------|-----------------------------------------------|
| Language           | Python 3.10+                                  |
| Web framework      | Django 6.1                                    |
| Database           | SQLite (default)                              |
| Frontend           | Bootstrap 5 (CDN) + Bootstrap Icons + custom CSS |
| Interactivity      | Vanilla JavaScript (modals, accordion, search) |
| Password hashing   | SHA-256 (via `hashlib`)                       |

## 📁 Project structure

```
hostel_web/
├── manage.py              # Django CLI
├── seed.py                # Seed script (run after migrate)
├── requirements.txt       # Just Django
├── hostel_web/            # Project (settings, urls, wsgi)
│   ├── settings.py
│   ├── urls.py
│   ├── wsgi.py
│   └── asgi.py
└── hostel/                # App
    ├── models.py          # WardenUser, Room, Student, Complaint, Notice
    ├── views.py           # All views + validators + auth decorators
    ├── urls.py            # 18 URL routes
    ├── admin.py
    ├── migrations/
    ├── static/css/style.css   # Modern flat theme
    └── templates/hostel/  # 13 templates
        ├── base.html          # Base layout (Bootstrap + CSS)
        ├── index.html         # Welcome page
        ├── warden_base.html   # Sidebar + topbar layout for warden
        ├── warden_login.html
        ├── student_login.html
        ├── warden_dashboard.html
        ├── students.html      # List + smart search + modal forms
        ├── rooms.html         # List + Add Room modal
        ├── complaints.html   # 3-state status workflow
        ├── notices.html       # Accordion list + Add Notice modal
        ├── student_dashboard.html
        ├── student_profile.html
        ├── submit_complaint.html
        └── student_notices.html
```

## ✨ Features

### Warden module
- **Dashboard** — stat cards (Total Students / Rooms / Available / Full) + recent complaints table
- **Students** — full-width list, smart search bar (type a name OR digits to search by room number),
  modal popups for Add/Edit/Delete with input validation, password eye icon (hold-to-reveal)
- **Rooms** — list + Add Room modal (capacity defaults to 4)
- **Complaints** — 3-state workflow: Pending (🟡) → In Progress (🔵) → Resolved (🟢),
  with "Reopen" button
- **Notices** — accordion list (click a title to expand, one open at a time) + Add Notice modal

### Student module
- **Dashboard** — action buttons (Profile, Complaint, Notices, Logout)
- **My Profile** — read-only details
- **Submit Complaint** — form with validation
- **View Notices** — accordion list (same as warden, read-only)

### Smart search (Students page)
- Type **pure text** (no digits) → searches by **student name** (case-insensitive)
- Type **anything with digits** → searches by **room number** (e.g. `04` matches room A04)
- Live count: `"2 of 5 · room contains '04'"`
- Auto-submits with 300ms debounce as you type

### Input validation
Same rules as the desktop app — email format, phone digit count (7–15), username
format, password length, room number format, capacity range (1–50).

## 🧪 Verified

All pages and flows tested end-to-end:
- Warden login → redirect to dashboard ✓
- All 5 warden pages load (200) ✓
- Smart search: "pradip" → 1 result, "04" → 2 results, "99" → 0 results ✓
- Student login → redirect to dashboard ✓
- All 4 student pages load (200) ✓
- Wrong password rejected (stays on login page) ✓
- Complaint status workflow (Pending → In Progress → Resolved) ✓
- Add Room / Add Student / Add Notice forms work ✓
- Validation rejects invalid email ✓
