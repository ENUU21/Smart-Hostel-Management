from django.db import models
import hashlib


class WardenUser(models.Model):
    """Warden login credentials (separate from Django's auth_user)."""
    username = models.CharField(max_length=50, unique=True)
    password = models.CharField(max_length=64)  # SHA-256 hex

    @staticmethod
    def hash_password(pw):
        return hashlib.sha256(pw.encode('utf-8')).hexdigest()

    def check_password(self, raw_password):
        return self.password == self.hash_password(raw_password)

    def __str__(self):
        return self.username


class Room(models.Model):
    roomnumber = models.CharField(max_length=10, unique=True)
    capacity = models.PositiveIntegerField(default=4)

    @property
    def occupied(self):
        return self.student_set.count()

    @property
    def available(self):
        return self.capacity - self.occupied

    @property
    def status(self):
        return "Full" if self.available <= 0 else "Available"

    def __str__(self):
        return self.roomnumber


class Student(models.Model):
    fullname = models.CharField(max_length=100)
    username = models.CharField(max_length=50, unique=True)
    password = models.CharField(max_length=64)  # SHA-256 hex
    email = models.EmailField(blank=True)
    phone = models.CharField(max_length=10, blank=True)  # 10-digit Indian mobile
    # Guardian / parent contact (required for every student)
    guardian_name = models.CharField(max_length=100, blank=True,
                                     default='')
    guardian_phone = models.CharField(max_length=10, blank=True,
                                       default='')  # 10-digit Indian mobile
    # Academic year (e.g. 2024, 2025, 2026) — used for "New Academic Year"
    # which clears all students from a specific year
    academic_year = models.PositiveIntegerField(default=2026)
    # Room is now required (null=False, blank=False) — every student must be
    # assigned a room at admission time. on_delete=PROTECT so a room cannot be
    # deleted while students are in it.
    room = models.ForeignKey(Room, on_delete=models.PROTECT)
    createdat = models.DateTimeField(auto_now_add=True)

    @staticmethod
    def hash_password(pw):
        return hashlib.sha256(pw.encode('utf-8')).hexdigest()

    def check_password(self, raw_password):
        return self.password == self.hash_password(raw_password)

    def __str__(self):
        return self.fullname


class Complaint(models.Model):
    STATUS_CHOICES = [
        ('Pending', 'Pending'),
        ('In Progress', 'In Progress'),
        ('Resolved', 'Resolved'),
    ]
    # Threshold for "overdue" pending complaints (in days)
    OVERDUE_DAYS = 3

    student = models.ForeignKey(Student, on_delete=models.CASCADE)
    title = models.CharField(max_length=100)
    description = models.TextField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES,
                              default='Pending')
    createdat = models.DateTimeField(auto_now_add=True)

    @property
    def is_overdue(self):
        """True if this complaint is Pending and older than OVERDUE_DAYS."""
        if self.status != 'Pending':
            return False
        from django.utils import timezone
        from datetime import timedelta
        return timezone.now() - self.createdat > timedelta(days=self.OVERDUE_DAYS)

    @property
    def age_days(self):
        """Age of this complaint in whole days."""
        from django.utils import timezone
        return (timezone.now() - self.createdat).days

    def __str__(self):
        return self.title


class Notice(models.Model):
    title = models.CharField(max_length=100)
    description = models.TextField()
    createdat = models.DateTimeField(auto_now_add=True)

    def __str__(self):
        return self.title


class LeaveRequest(models.Model):
    """A student's request to leave the hostel (vacation / home visit).

    Flow: student creates → warden approves → student gets a gate pass.
    """
    STATUS_CHOICES = [
        ('Pending', 'Pending'),
        ('Approved', 'Approved'),
        ('Rejected', 'Rejected'),
    ]
    student = models.ForeignKey(Student, on_delete=models.CASCADE,
                                related_name='leave_requests')
    from_date = models.DateField()
    to_date = models.DateField()
    destination = models.CharField(max_length=200)
    reason = models.TextField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES,
                              default='Pending')
    warden_remark = models.TextField(blank=True, default='')
    createdat = models.DateTimeField(auto_now_add=True)
    approved_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return f"{self.student.fullname} — {self.from_date} to {self.to_date}"


class RoomChangeRequest(models.Model):
    """A student's request to move to a different room.

    Flow: student creates → warden approves → student's room is changed.
    """
    STATUS_CHOICES = [
        ('Pending', 'Pending'),
        ('Approved', 'Approved'),
        ('Rejected', 'Rejected'),
    ]
    student = models.ForeignKey(Student, on_delete=models.CASCADE,
                                related_name='room_change_requests')
    requested_room = models.ForeignKey(Room, on_delete=models.CASCADE,
                                       related_name='change_requests')
    reason = models.TextField()
    status = models.CharField(max_length=20, choices=STATUS_CHOICES,
                              default='Pending')
    warden_remark = models.TextField(blank=True, default='')
    createdat = models.DateTimeField(auto_now_add=True)
    approved_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return (f"{self.student.fullname} → "
                f"Room {self.requested_room.roomnumber}")


class RoomSwapRequest(models.Model):
    """Two students exchange rooms directly.

    Flow:
      1. Student A initiates → requests swap with Student B
      2. Student B accepts or rejects the swap
      3. If B accepts → warden approves → both students' rooms are swapped

    This solves the "both rooms are full" deadlock: A wants B's room,
    B wants A's room, but neither can move until the other leaves first.
    A swap exchanges them atomically.
    """
    STATUS_CHOICES = [
        ('Pending', 'Pending'),               # awaiting B's acceptance
        ('Accepted by Peer', 'Accepted by Peer'),  # B said yes, awaiting warden
        ('Approved', 'Approved'),             # warden approved — swap done
        ('Rejected by Peer', 'Rejected by Peer'),   # B said no
        ('Rejected by Warden', 'Rejected by Warden'),
    ]
    requester = models.ForeignKey(Student, on_delete=models.CASCADE,
                                  related_name='swap_requests_initiated')
    target = models.ForeignKey(Student, on_delete=models.CASCADE,
                               related_name='swap_requests_received')
    reason = models.TextField()
    status = models.CharField(max_length=30, choices=STATUS_CHOICES,
                              default='Pending')
    warden_remark = models.TextField(blank=True, default='')
    createdat = models.DateTimeField(auto_now_add=True)
    approved_at = models.DateTimeField(null=True, blank=True)

    def __str__(self):
        return (f"Swap: {self.requester.fullname} "
                f"(Room {self.requester.room.roomnumber if self.requester.room else '—'}) "
                f"↔ {self.target.fullname} "
                f"(Room {self.target.room.roomnumber if self.target.room else '—'})")
