from django.shortcuts import render, redirect, get_object_or_404
from django.contrib import messages
from django.http import JsonResponse
from django.utils import timezone
from django.db.models import Count
from .models import (WardenUser, Room, Student, Complaint, Notice,
                     LeaveRequest, RoomChangeRequest, RoomSwapRequest)
import re


# ---------------------------------------------------------------------------
# Input validators
# ---------------------------------------------------------------------------
EMAIL_RE = re.compile(r'^[A-Za-z0-9._%+\-]{2,64}@[A-Za-z0-9.\-]{2,253}\.'
                      r'[A-Za-z]{2,}$')
USERNAME_RE = re.compile(r'^[A-Za-z][A-Za-z0-9_]{2,29}$')
# Indian mobile: exactly 10 digits, starting with 6/7/8/9.
INDIAN_MOBILE_RE = re.compile(r'^[6-9]\d{9}$')


def _validate_mobile(value, field_name, label):
    """Validate an Indian mobile number. Returns (ok, errors_dict_fragment)."""
    errors = {}
    v = (value or '').strip()
    if not v:
        errors[field_name] = f"{label} is required."
    elif not v.isdigit():
        errors[field_name] = (f"{label} must contain only digits "
                              "(no spaces, +, -, or letters).")
    elif len(v) != 10:
        errors[field_name] = f"{label} must be exactly 10 digits."
    elif not v[0] in '6789':
        errors[field_name] = (f"{label} must start with 6, 7, 8, or 9 "
                              "(Indian mobile).")
    return errors


def validate_student_fields_per_field(name, username, password, email, phone,
                                      guardian_name, guardian_phone,
                                      password_required=True):
    """Return (ok, errors_dict) where errors_dict maps field name → message.

    Only contains keys for fields that failed validation.
    """
    errors = {}

    name = (name or '').strip()
    if len(name) < 2:
        errors['fullname'] = "Name must be at least 2 characters."
    elif len(name) > 100:
        errors['fullname'] = "Name is too long (max 100 characters)."

    username = (username or '').strip()
    if not USERNAME_RE.match(username):
        errors['username'] = ("Username must be 3-30 chars, start with a "
                              "letter, only letters/digits/underscore.")

    if password:
        if len(password) < 4:
            errors['password'] = "Password must be at least 4 characters."
        elif len(password) > 64:
            errors['password'] = "Password is too long (max 64 characters)."
    elif password_required:
        errors['password'] = "Password is required."

    email = (email or '').strip()
    if not email:
        errors['email'] = "Email is required."
    elif not EMAIL_RE.match(email):
        errors['email'] = "Email format is invalid (expected name@domain.tld)."

    # Indian mobile validation for student's own phone
    errors.update(_validate_mobile(phone, 'phone', "Phone number"))

    # Guardian fields
    guardian_name = (guardian_name or '').strip()
    if len(guardian_name) < 2:
        errors['guardian_name'] = ("Guardian name must be at least "
                                    "2 characters.")
    elif len(guardian_name) > 100:
        errors['guardian_name'] = ("Guardian name is too long "
                                    "(max 100 characters).")
    # Indian mobile validation for guardian phone
    errors.update(_validate_mobile(guardian_phone, 'guardian_phone',
                                    "Guardian phone"))

    return (len(errors) == 0), errors


# Backward-compat wrapper (old callers that don't pass guardian fields)
def validate_student_fields(name, username, password, email, phone,
                            password_required=True):
    ok, errors = validate_student_fields_per_field(
        name, username, password, email, phone, '', '',
        password_required)
    # Return a single error string for the old signature
    if ok:
        return True, None
    first_key = next(iter(errors), None)
    return False, errors.get(first_key, "Validation failed.")


def validate_room_fields(room_number, capacity):
    """Return (ok, errors_dict) where errors_dict maps field name → message."""
    errors = {}
    room_number = (room_number or '').strip()
    if not room_number:
        errors['roomnumber'] = "Room number is required."
    elif len(room_number) > 10:
        errors['roomnumber'] = "Room number is too long (max 10 characters)."
    elif not re.match(r'^[A-Za-z0-9\-]{1,10}$', room_number):
        errors['roomnumber'] = ("Room number may only contain letters, "
                                "digits, and hyphens.")
    try:
        n = int(capacity)
        if n < 1:
            errors['capacity'] = "Capacity must be at least 1."
        elif n > 50:
            errors['capacity'] = "Capacity is too large (max 50)."
    except (TypeError, ValueError):
        errors['capacity'] = "Capacity must be a whole number."
    return (len(errors) == 0), errors


# ---------------------------------------------------------------------------
# Auth helpers
# ---------------------------------------------------------------------------
def warden_required(view_func):
    """Decorator: redirect to warden login if not logged in."""
    def wrapper(request, *args, **kwargs):
        if not request.session.get('warden_id'):
            return redirect('warden_login')
        return view_func(request, *args, **kwargs)
    return wrapper


def student_required(view_func):
    """Decorator: redirect to student login if not logged in."""
    def wrapper(request, *args, **kwargs):
        if not request.session.get('student_id'):
            return redirect('student_login')
        return view_func(request, *args, **kwargs)
    return wrapper


# ---------------------------------------------------------------------------
# Home + auth
# ---------------------------------------------------------------------------
def home(request):
    return render(request, 'hostel/index.html')


def warden_login(request):
    if request.method == 'POST':
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password', '').strip()
        try:
            warden = WardenUser.objects.get(username=username)
            if warden.check_password(password):
                request.session['warden_id'] = warden.id
                request.session['warden_name'] = warden.username
                return redirect('warden_dashboard')
        except WardenUser.DoesNotExist:
            pass
        return render(request, 'hostel/warden_login.html',
                      {'error': 'Invalid username or password.'})
    return render(request, 'hostel/warden_login.html')


def warden_logout(request):
    for k in ('warden_id', 'warden_name'):
        request.session.pop(k, None)
    return redirect('home')


def student_login(request):
    if request.method == 'POST':
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password', '').strip()
        try:
            student = Student.objects.get(username=username)
            if student.check_password(password):
                request.session['student_id'] = student.id
                # Go directly to profile page (no dashboard menu)
                return redirect('student_profile')
        except Student.DoesNotExist:
            pass
        return render(request, 'hostel/student_login.html',
                      {'error': 'Invalid username or password.'})
    return render(request, 'hostel/student_login.html')


def student_logout(request):
    request.session.pop('student_id', None)
    return redirect('home')


# ---------------------------------------------------------------------------
# Warden: Dashboard
# ---------------------------------------------------------------------------
@warden_required
def warden_dashboard(request):
    total_students = Student.objects.count()
    total_rooms = Room.objects.count()
    rooms = Room.objects.all()
    full_rooms = sum(1 for r in rooms if r.available <= 0)
    available_rooms = total_rooms - full_rooms
    recent_complaints = Complaint.objects.select_related(
        'student', 'student__room').order_by('-createdat')[:8]
    # Pending request counts for dashboard badges
    pending_leaves = LeaveRequest.objects.filter(status='Pending').count()
    pending_room_changes = RoomChangeRequest.objects.filter(
        status='Pending').count()
    pending_complaints = Complaint.objects.filter(
        status='Pending').count()
    # "All rooms full" flag for the dashboard banner
    rooms_with_space = [r for r in rooms if r.available > 0]
    all_rooms_full = (total_rooms > 0 and len(rooms_with_space) == 0)
    context = {
        'warden_name': request.session.get('warden_name', 'Warden'),
        'total_students': total_students,
        'total_rooms': total_rooms,
        'available_rooms': available_rooms,
        'full_rooms': full_rooms,
        'recent_complaints': recent_complaints,
        'pending_leaves': pending_leaves,
        'pending_room_changes': pending_room_changes,
        'pending_complaints': pending_complaints,
        'all_rooms_full': all_rooms_full,
    }
    return render(request, 'hostel/warden_dashboard.html', context)


# ---------------------------------------------------------------------------
# Warden: Students (list + smart search + add/edit/delete)
# ---------------------------------------------------------------------------
@warden_required
def students(request):
    q = request.GET.get('q', '').strip()
    # Sort by room number (nulls last), then by name within the same room
    all_students = Student.objects.select_related('room').order_by(
        'room__roomnumber', 'fullname')

    if q:
        has_digit = any(ch.isdigit() for ch in q)
        if has_digit:
            # Room-number search (alphanumeric substring match)
            q_norm = ''.join(ch for ch in q if ch.isalnum()).lower()
            all_students = [s for s in all_students
                           if q_norm in (s.room.roomnumber if s.room
                                         else '').lower()]
            search_kind = "room contains '%s'" % q
        else:
            ql = q.lower()
            matched = [s for s in all_students
                       if ql in (s.fullname or '').lower()]
            # Contacts-app-style ordering:
            #   Priority 0 — name starts with the query
            #   Priority 1 — query appears at the start of a word in the name
            #   Priority 2 — query appears elsewhere in the name
            def sort_key(s):
                name = (s.fullname or '').lower()
                if name.startswith(ql):
                    priority = 0
                elif any(word.startswith(ql) for word in name.split()):
                    priority = 1
                else:
                    priority = 2
                return (priority, name)
            all_students = sorted(matched, key=sort_key)
            search_kind = "name contains '%s'" % q
    else:
        search_kind = None

    total = Student.objects.count()
    shown = len(all_students)
    # Only rooms with available beds for the Add/Edit modal dropdown
    all_rooms = list(Room.objects.all().order_by('roomnumber'))
    rooms_with_space = [r for r in all_rooms if r.available > 0]
    all_rooms_full = (len(all_rooms) > 0 and len(rooms_with_space) == 0)
    context = {
        'warden_name': request.session.get('warden_name', 'Warden'),
        'students': all_students,
        'query': q,
        'shown': shown,
        'total': total,
        'search_kind': search_kind,
        'all_rooms': rooms_with_space,  # only rooms with beds available
        'all_rooms_full': all_rooms_full,
    }
    return render(request, 'hostel/students.html', context)


@warden_required
def student_add(request):
    """Handle Add Student form submission (POST from modal).

    On validation failure, re-renders the students page with per-field error
    messages so the modal can be reopened showing the errors inline.
    """
    if request.method == 'POST':
        name = request.POST.get('fullname', '').strip()
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password', '').strip()
        email = request.POST.get('email', '').strip()
        phone = request.POST.get('phone', '').strip()
        guardian_name = request.POST.get('guardian_name', '').strip()
        guardian_phone = request.POST.get('guardian_phone', '').strip()
        room_id = request.POST.get('room', '')
        academic_year = request.POST.get('academic_year', '').strip()

        ok, errors = validate_student_fields_per_field(
            name, username, password, email, phone,
            guardian_name, guardian_phone, password_required=True)

        # Check username uniqueness even if other fields are invalid
        if Student.objects.filter(username=username).exists():
            errors['username'] = "Username already exists."

        # Room is now required — every student must be assigned a room.
        room = None
        if not room_id:
            errors['room'] = "Please assign a room to the student."
        else:
            try:
                room = Room.objects.get(id=room_id)
                if room.available <= 0:
                    errors['room'] = "That room is already full."
            except Room.DoesNotExist:
                errors['room'] = "Invalid room selected."

        if not ok or errors:
            # Re-render the students page with the submitted values preserved
            # and per-field errors so the modal reopens showing them.
            all_students = Student.objects.select_related(
                'room').order_by('room__roomnumber', 'fullname')
            all_rooms = list(Room.objects.all().order_by('roomnumber'))
            rooms_with_space = [r for r in all_rooms if r.available > 0]
            return render(request, 'hostel/students.html', {
                'warden_name': request.session.get('warden_name', 'Warden'),
                'students': all_students,
                'query': '',
                'shown': Student.objects.count(),
                'total': Student.objects.count(),
                'search_kind': None,
                'all_rooms': rooms_with_space,
                'all_rooms_full': (len(all_rooms) > 0 and len(rooms_with_space) == 0),
                'form_errors': errors,
                'form_mode': 'add',
                'form_values': {
                    'fullname': name, 'username': username,
                    'email': email, 'phone': phone,
                    'guardian_name': guardian_name,
                    'guardian_phone': guardian_phone,
                    'room': room_id,
                },
            })

        Student.objects.create(
            fullname=name, username=username,
            password=Student.hash_password(password),
            email=email, phone=phone, room=room,
            guardian_name=guardian_name, guardian_phone=guardian_phone,
            academic_year=int(academic_year) if academic_year else 2026,
        )
        messages.success(request, "Student added successfully.")
        return redirect('students')
    return redirect('students')


@warden_required
def student_edit(request, sid):
    student = get_object_or_404(Student, id=sid)
    if request.method == 'POST':
        name = request.POST.get('fullname', '').strip()
        username = request.POST.get('username', '').strip()
        password = request.POST.get('password', '').strip()  # blank = keep
        email = request.POST.get('email', '').strip()
        phone = request.POST.get('phone', '').strip()
        guardian_name = request.POST.get('guardian_name', '').strip()
        guardian_phone = request.POST.get('guardian_phone', '').strip()
        room_id = request.POST.get('room', '')
        academic_year = request.POST.get('academic_year', '').strip()

        ok, errors = validate_student_fields_per_field(
            name, username, password, email, phone,
            guardian_name, guardian_phone, password_required=False)

        # Check username uniqueness (excluding self)
        if Student.objects.filter(username=username).exclude(id=sid).exists():
            errors['username'] = "Username already exists."

        # Room is required — must always have one assigned.
        room = None
        if not room_id:
            errors['room'] = "Please assign a room to the student."
        else:
            try:
                room = Room.objects.get(id=room_id)
                current_room_id = student.room.id if student.room else None
                if room.available <= 0 and room.id != current_room_id:
                    errors['room'] = "That room is already full."
            except Room.DoesNotExist:
                errors['room'] = "Invalid room selected."

        if not ok or errors:
            all_students = Student.objects.select_related(
                'room').order_by('room__roomnumber', 'fullname')
            all_rooms = list(Room.objects.all().order_by('roomnumber'))
            # For edit mode: include rooms with space + the student's
            # current room (so they can keep it even if it's now full)
            current_room_id = student.room.id if student.room else None
            rooms_for_dropdown = [
                r for r in all_rooms
                if r.available > 0 or r.id == current_room_id
            ]
            rooms_with_space = [r for r in all_rooms if r.available > 0]
            return render(request, 'hostel/students.html', {
                'warden_name': request.session.get('warden_name', 'Warden'),
                'students': all_students,
                'query': '',
                'shown': Student.objects.count(),
                'total': Student.objects.count(),
                'search_kind': None,
                'all_rooms': rooms_for_dropdown,
                'all_rooms_full': (len(all_rooms) > 0 and len(rooms_with_space) == 0),
                'form_errors': errors,
                'form_mode': 'edit',
                'form_edit_id': sid,
                'form_values': {
                    'fullname': name, 'username': username,
                    'email': email, 'phone': phone,
                    'guardian_name': guardian_name,
                    'guardian_phone': guardian_phone,
                    'room': room_id,
                },
            })

        student.fullname = name
        student.username = username
        student.email = email
        student.phone = phone
        student.guardian_name = guardian_name
        student.guardian_phone = guardian_phone
        student.room = room
        if academic_year:
            student.academic_year = int(academic_year)
        if password:
            student.password = Student.hash_password(password)
        student.save()
        messages.success(request, "Student updated successfully.")
        return redirect('students')
    return redirect('students')


@warden_required
def student_delete(request, sid):
    student = get_object_or_404(Student, id=sid)
    if request.method == 'POST':
        student.delete()
        messages.success(request, "Student deleted.")
        return redirect('students')
    return redirect('students')


# ---------------------------------------------------------------------------
# Warden: Rooms
# ---------------------------------------------------------------------------
@warden_required
def rooms(request):
    all_rooms = Room.objects.all().order_by('roomnumber')
    # Distinct academic years for the "New Academic Year" dropdown
    academic_years = Student.objects.values_list('academic_year',
        flat=True).distinct().order_by('-academic_year')
    context = {
        'warden_name': request.session.get('warden_name', 'Warden'),
        'rooms': all_rooms,
        'student_count': Student.objects.count(),
        'academic_years': list(academic_years),
    }
    return render(request, 'hostel/rooms.html', context)


@warden_required
def room_add(request):
    if request.method == 'POST':
        room_number = request.POST.get('roomnumber', '').strip()
        capacity = request.POST.get('capacity', '4')
        ok, errors = validate_room_fields(room_number, capacity)
        if Room.objects.filter(roomnumber=room_number).exists():
            errors['roomnumber'] = "Room number already exists."
        if not ok or errors:
            all_rooms = Room.objects.all().order_by('roomnumber')
            return render(request, 'hostel/rooms.html', {
                'warden_name': request.session.get('warden_name', 'Warden'),
                'rooms': all_rooms,
                'form_errors': errors,
                'form_values': {
                    'roomnumber': room_number, 'capacity': capacity,
                },
            })
        Room.objects.create(roomnumber=room_number, capacity=int(capacity))
        messages.success(request, "Room added successfully.")
        return redirect('rooms')
    return redirect('rooms')


@warden_required
def room_delete(request, rid):
    """Delete a room. Refuses if the room has students in it (since room is
    PROTECT on the Student model)."""
    room = get_object_or_404(Room, id=rid)
    if request.method == 'POST':
        if room.occupied > 0:
            messages.error(request, f"Cannot delete Room {room.roomnumber} — "
                           f"it still has {room.occupied} student(s) "
                           f"assigned. Move them to other rooms first.")
            return redirect('rooms')
        room_number = room.roomnumber
        room.delete()
        messages.success(request, f"Room {room_number} deleted.")
        return redirect('rooms')
    return redirect('rooms')


@warden_required
def new_academic_year(request):
    """Clear students from a specific academic year (or all) to start a new
    academic year. Rooms, notices, and the warden account are preserved."""
    if request.method == 'POST':
        confirm = request.POST.get('confirm', '').strip()
        target_year = request.POST.get('year', '').strip()
        if confirm != 'CLEAR':
            messages.error(request, "Confirmation text did not match. "
                           "Type 'CLEAR' to confirm.")
            return redirect('rooms')
        if target_year == 'all':
            count = Student.objects.count()
            Student.objects.all().delete()
            messages.success(request, f"All {count} student(s) cleared "
                             f"(all years). Rooms and notices preserved.")
        else:
            try:
                yr = int(target_year)
            except ValueError:
                messages.error(request, "Invalid year selected.")
                return redirect('rooms')
            count = Student.objects.filter(academic_year=yr).count()
            Student.objects.filter(academic_year=yr).delete()
            messages.success(request, f"{count} student(s) from {yr} "
                             f"cleared. Rooms and notices preserved.")
        return redirect('rooms')
    return redirect('rooms')


# ---------------------------------------------------------------------------
# Warden: Complaints
# ---------------------------------------------------------------------------
@warden_required
def complaints(request):
    all_complaints = list(Complaint.objects.select_related(
        'student', 'student__room').order_by('-createdat'))
    # Count overdue complaints (pending for >3 days) for the header badge
    overdue_count = sum(1 for c in all_complaints if c.is_overdue)
    context = {
        'warden_name': request.session.get('warden_name', 'Warden'),
        'complaints': all_complaints,
        'overdue_count': overdue_count,
    }
    return render(request, 'hostel/complaints.html', context)


@warden_required
def complaint_set_status(request, cid, status):
    if status not in ('Pending', 'In Progress', 'Resolved'):
        messages.error(request, "Invalid status.")
        return redirect('complaints')
    complaint = get_object_or_404(Complaint, id=cid)
    complaint.status = status
    complaint.save()
    messages.success(request, f"Complaint marked as {status}.")
    return redirect('complaints')


# ---------------------------------------------------------------------------
# Warden: Notices (accordion)
# ---------------------------------------------------------------------------
@warden_required
def notices(request):
    all_notices = Notice.objects.all().order_by('-createdat')
    context = {
        'warden_name': request.session.get('warden_name', 'Warden'),
        'notices': all_notices,
    }
    return render(request, 'hostel/notices.html', context)


@warden_required
def notice_add(request):
    if request.method == 'POST':
        title = request.POST.get('title', '').strip()
        description = request.POST.get('description', '').strip()
        if len(title) < 3:
            messages.error(request, "Title must be at least 3 characters.")
            return redirect('notices')
        if len(description) < 5:
            messages.error(request,
                           "Description must be at least 5 characters.")
            return redirect('notices')
        Notice.objects.create(title=title, description=description)
        messages.success(request, "Notice posted successfully.")
        return redirect('notices')
    return redirect('notices')


# ---------------------------------------------------------------------------
# Student views
# ---------------------------------------------------------------------------
@student_required
def student_dashboard(request):
    student = get_object_or_404(Student, id=request.session['student_id'])
    return render(request, 'hostel/student_dashboard.html',
                  {'student': student})


@student_required
def student_profile(request):
    student = get_object_or_404(Student, id=request.session['student_id'])
    my_complaints = Complaint.objects.filter(
        student=student).order_by('-createdat')[:5]
    my_leaves = LeaveRequest.objects.filter(
        student=student).order_by('-createdat')[:5]
    my_room_changes = RoomChangeRequest.objects.filter(
        student=student).order_by('-createdat')[:5]
    context = {
        'student': student,
        'my_complaints': my_complaints,
        'my_leaves': my_leaves,
        'my_room_changes': my_room_changes,
        'complaints_count': Complaint.objects.filter(student=student).count(),
        'leaves_count': LeaveRequest.objects.filter(student=student).count(),
        'room_changes_count': RoomChangeRequest.objects.filter(
            student=student).count(),
    }
    return render(request, 'hostel/student_profile.html', context)


@student_required
def submit_complaint(request):
    student = get_object_or_404(Student, id=request.session['student_id'])
    if request.method == 'POST':
        title = request.POST.get('title', '').strip()
        description = request.POST.get('description', '').strip()
        if len(title) < 3:
            messages.error(request, "Title must be at least 3 characters.")
            return redirect('submit_complaint')
        if len(description) < 5:
            messages.error(request,
                           "Description must be at least 5 characters.")
            return redirect('submit_complaint')
        Complaint.objects.create(student=student, title=title,
                                 description=description)
        messages.success(request, "Complaint submitted successfully.")
        return redirect('student_dashboard')
    return render(request, 'hostel/submit_complaint.html',
                  {'student': student})


@student_required
def student_notices(request):
    all_notices = Notice.objects.all().order_by('-createdat')
    return render(request, 'hostel/student_notices.html',
                  {'notices': all_notices})


# ---------------------------------------------------------------------------
# Student: Leave requests + Gate pass
# ---------------------------------------------------------------------------
@student_required
def student_leave_request(request):
    """List the student's own leave requests."""
    student = get_object_or_404(Student, id=request.session['student_id'])
    my_leaves = LeaveRequest.objects.filter(
        student=student).order_by('-createdat')
    return render(request, 'hostel/student_leave_request.html', {
        'student': student,
        'my_leaves': my_leaves,
    })


@student_required
def student_leave_request_new(request):
    """Create a new leave request (student side)."""
    student = get_object_or_404(Student, id=request.session['student_id'])
    if request.method == 'POST':
        from_date = request.POST.get('from_date', '').strip()
        to_date = request.POST.get('to_date', '').strip()
        destination = request.POST.get('destination', '').strip()
        reason = request.POST.get('reason', '').strip()

        errors = {}
        if not from_date:
            errors['from_date'] = "From date is required."
        if not to_date:
            errors['to_date'] = "To date is required."
        if from_date and to_date and to_date < from_date:
            errors['to_date'] = "To date must be after the from date."
        if len(destination) < 3:
            errors['destination'] = ("Destination must be at least "
                                     "3 characters.")
        if len(reason) < 5:
            errors['reason'] = "Reason must be at least 5 characters."

        if errors:
            all_rooms = list(Room.objects.all().order_by('roomnumber'))
            return render(request, 'hostel/student_leave_request.html', {
                'student': student,
                'my_leaves': LeaveRequest.objects.filter(
                    student=student).order_by('-createdat'),
                'form_errors': errors,
                'form_values': {
                    'from_date': from_date, 'to_date': to_date,
                    'destination': destination, 'reason': reason,
                },
                'show_modal': True,
            })

        LeaveRequest.objects.create(
            student=student, from_date=from_date, to_date=to_date,
            destination=destination, reason=reason,
        )
        messages.success(request, "Leave request submitted. "
                         "Waiting for warden approval.")
        return redirect('student_leave_request')
    return redirect('student_leave_request')


@student_required
def student_gate_pass(request, lid):
    """Display a printable gate pass for an approved leave request."""
    student = get_object_or_404(Student, id=request.session['student_id'])
    leave = get_object_or_404(LeaveRequest, id=lid, student=student)
    if leave.status != 'Approved':
        messages.error(request, "Gate pass is only available for "
                       "approved leave requests.")
        return redirect('student_leave_request')
    return render(request, 'hostel/student_gate_pass.html', {
        'student': student,
        'leave': leave,
        'warden_name': request.session.get('warden_name', 'Warden'),
    })


# ---------------------------------------------------------------------------
# Student: Room Transfer (unified: move to empty room OR swap with a peer)
# ---------------------------------------------------------------------------
def _has_active_transfer(student):
    """Check if the student has ANY pending room transfer request (move
    or swap). Returns True if they do — used to block creating a second
    request while one is already active."""
    # Pending room change request
    if RoomChangeRequest.objects.filter(
            student=student, status='Pending').exists():
        return True
    # Pending or accepted-by-peer swap request (initiated by this student)
    if RoomSwapRequest.objects.filter(
            requester=student,
            status__in=['Pending', 'Accepted by Peer']).exists():
        return True
    # Pending or accepted-by-peer swap request (received by this student)
    if RoomSwapRequest.objects.filter(
            target=student,
            status__in=['Pending', 'Accepted by Peer']).exists():
        return True
    return False


@student_required
def student_room_transfer(request):
    """Unified room transfer page: shows move requests, swap requests
    (initiated + received), and has buttons to create either type."""
    student = get_object_or_404(Student, id=request.session['student_id'])
    my_moves = RoomChangeRequest.objects.filter(
        student=student).order_by('-createdat')
    my_swaps_sent = RoomSwapRequest.objects.filter(
        requester=student).order_by('-createdat')
    my_swaps_received = RoomSwapRequest.objects.filter(
        target=student).order_by('-createdat')
    # Data for the modals
    available_rooms = Room.objects.exclude(
        id=student.room.id if student.room else 0).order_by('roomnumber')
    rooms_with_space = [r for r in available_rooms if r.available > 0]
    other_students = Student.objects.exclude(id=student.id).order_by(
        'room__roomnumber', 'fullname')
    # Can the student create a new request?
    can_request = not _has_active_transfer(student)
    return render(request, 'hostel/student_room_transfer.html', {
        'student': student,
        'my_moves': my_moves,
        'my_swaps_sent': my_swaps_sent,
        'my_swaps_received': my_swaps_received,
        'rooms_with_space': rooms_with_space,
        'other_students': other_students,
        'can_request': can_request,
    })


@student_required
def student_room_change_new(request):
    """Create a new room change request (move to an empty room)."""
    student = get_object_or_404(Student, id=request.session['student_id'])
    if request.method == 'POST':
        # Block if already has an active transfer
        if _has_active_transfer(student):
            messages.error(request, "You already have an active room "
                           "transfer request. Wait for it to be resolved "
                           "before creating a new one.")
            return redirect('student_room_transfer')

        requested_room_id = request.POST.get('requested_room', '').strip()
        reason = request.POST.get('reason', '').strip()

        errors = {}
        if not requested_room_id:
            errors['requested_room'] = "Please select a room."
        else:
            try:
                room = Room.objects.get(id=requested_room_id)
                if student.room and room.id == student.room.id:
                    errors['requested_room'] = ("You are already in this "
                                                "room.")
                if room.available <= 0:
                    errors['requested_room'] = "That room is already full."
            except Room.DoesNotExist:
                errors['requested_room'] = "Invalid room selected."
        if len(reason) < 5:
            errors['reason'] = "Reason must be at least 5 characters."

        available_rooms = Room.objects.exclude(
            id=student.room.id if student.room else 0).order_by('roomnumber')
        rooms_with_space = [r for r in available_rooms if r.available > 0]
        other_students = Student.objects.exclude(id=student.id).order_by(
            'room__roomnumber', 'fullname')
        if errors:
            return render(request, 'hostel/student_room_transfer.html', {
                'student': student,
                'my_moves': RoomChangeRequest.objects.filter(
                    student=student).order_by('-createdat'),
                'my_swaps_sent': RoomSwapRequest.objects.filter(
                    requester=student).order_by('-createdat'),
                'my_swaps_received': RoomSwapRequest.objects.filter(
                    target=student).order_by('-createdat'),
                'rooms_with_space': rooms_with_space,
                'other_students': other_students,
                'can_request': not _has_active_transfer(student),
                'form_errors_move': errors,
                'form_values_move': {
                    'requested_room': requested_room_id,
                    'reason': reason,
                },
                'show_move_modal': True,
            })

        RoomChangeRequest.objects.create(
            student=student, requested_room=room, reason=reason,
        )
        messages.success(request, "Room change request submitted. "
                         "Waiting for warden approval.")
        return redirect('student_room_transfer')
    return redirect('student_room_transfer')


@student_required
def student_room_swap_new(request):
    """Create a new room swap request (swap with another student)."""
    student = get_object_or_404(Student, id=request.session['student_id'])
    if request.method == 'POST':
        # Block if already has an active transfer
        if _has_active_transfer(student):
            messages.error(request, "You already have an active room "
                           "transfer request. Wait for it to be resolved "
                           "before creating a new one.")
            return redirect('student_room_transfer')

        target_id = request.POST.get('target', '').strip()
        reason = request.POST.get('reason', '').strip()

        errors = {}
        if not target_id:
            errors['target'] = "Please select a student to swap with."
        else:
            try:
                target = Student.objects.get(id=target_id)
                if target.id == student.id:
                    errors['target'] = "You cannot swap with yourself."
                elif not target.room:
                    errors['target'] = ("That student doesn't have a room "
                                        "assigned.")
                # Also check if the target already has an active transfer
                elif _has_active_transfer(target):
                    errors['target'] = (f"{target.fullname} already has an "
                                        f"active room transfer request.")
            except Student.DoesNotExist:
                errors['target'] = "Invalid student selected."
        if len(reason) < 5:
            errors['reason'] = "Reason must be at least 5 characters."

        available_rooms = Room.objects.exclude(
            id=student.room.id if student.room else 0).order_by('roomnumber')
        rooms_with_space = [r for r in available_rooms if r.available > 0]
        other_students = Student.objects.exclude(id=student.id).order_by(
            'room__roomnumber', 'fullname')
        if errors:
            return render(request, 'hostel/student_room_transfer.html', {
                'student': student,
                'my_moves': RoomChangeRequest.objects.filter(
                    student=student).order_by('-createdat'),
                'my_swaps_sent': RoomSwapRequest.objects.filter(
                    requester=student).order_by('-createdat'),
                'my_swaps_received': RoomSwapRequest.objects.filter(
                    target=student).order_by('-createdat'),
                'rooms_with_space': rooms_with_space,
                'other_students': other_students,
                'can_request': not _has_active_transfer(student),
                'form_errors_swap': errors,
                'form_values_swap': {'target': target_id, 'reason': reason},
                'show_swap_modal': True,
            })

        RoomSwapRequest.objects.create(
            requester=student, target=target, reason=reason,
        )
        messages.success(request, f"Room swap request sent to "
                         f"{target.fullname}. They need to accept it "
                         f"before the warden can approve.")
        return redirect('student_room_transfer')
    return redirect('student_room_transfer')


@student_required
def student_room_swap_accept(request, sid):
    """Target student accepts the swap request."""
    student = get_object_or_404(Student, id=request.session['student_id'])
    swap = get_object_or_404(RoomSwapRequest, id=sid, target=student)
    if swap.status != 'Pending':
        messages.error(request, "This swap request is no longer pending.")
        return redirect('student_room_transfer')
    swap.status = 'Accepted by Peer'
    swap.save()
    messages.success(request, f"You accepted the swap request from "
                     f"{swap.requester.fullname}. Waiting for warden "
                     f"approval.")
    return redirect('student_room_transfer')


@student_required
def student_room_swap_reject(request, sid):
    """Target student rejects the swap request."""
    student = get_object_or_404(Student, id=request.session['student_id'])
    swap = get_object_or_404(RoomSwapRequest, id=sid, target=student)
    if swap.status != 'Pending':
        messages.error(request, "This swap request is no longer pending.")
        return redirect('student_room_transfer')
    swap.status = 'Rejected by Peer'
    swap.save()
    messages.success(request, f"You rejected the swap request from "
                     f"{swap.requester.fullname}.")
    return redirect('student_room_transfer')


@student_required
def student_room_change_cancel(request, rid):
    """Student cancels their own pending room change (move) request."""
    student = get_object_or_404(Student, id=request.session['student_id'])
    req = get_object_or_404(RoomChangeRequest, id=rid, student=student)
    if req.status != 'Pending':
        messages.error(request, "Only pending requests can be cancelled.")
        return redirect('student_room_transfer')
    req.status = 'Rejected'
    req.warden_remark = 'Cancelled by student'
    req.save()
    messages.success(request, "Room change request cancelled.")
    return redirect('student_room_transfer')


@student_required
def student_room_swap_cancel(request, sid):
    """Student cancels their own pending swap request (as requester)."""
    student = get_object_or_404(Student, id=request.session['student_id'])
    swap = get_object_or_404(RoomSwapRequest, id=sid, requester=student)
    if swap.status not in ('Pending', 'Accepted by Peer'):
        messages.error(request, "Only pending or accepted swaps can be "
                       "cancelled.")
        return redirect('student_room_transfer')
    swap.status = 'Rejected by Peer'  # reuse as "cancelled"
    swap.save()
    messages.success(request, "Room swap request cancelled.")
    return redirect('student_room_transfer')


# ---------------------------------------------------------------------------
# Warden: Leave requests
# ---------------------------------------------------------------------------
@warden_required
def leave_requests(request):
    """Warden: list all leave requests, grouped by status."""
    all_leaves = LeaveRequest.objects.select_related(
        'student', 'student__room').order_by('-createdat')
    pending = [l for l in all_leaves if l.status == 'Pending']
    approved = [l for l in all_leaves if l.status == 'Approved']
    rejected = [l for l in all_leaves if l.status == 'Rejected']
    context = {
        'warden_name': request.session.get('warden_name', 'Warden'),
        'pending': pending,
        'approved': approved,
        'rejected': rejected,
    }
    return render(request, 'hostel/warden_leave_requests.html', context)


@warden_required
def leave_request_approve(request, lid):
    leave = get_object_or_404(LeaveRequest, id=lid)
    if request.method == 'POST':
        remark = request.POST.get('remark', '').strip()
        leave.status = 'Approved'
        leave.warden_remark = remark
        leave.approved_at = timezone.now()
        leave.save()
        messages.success(request, f"Leave request approved for "
                         f"{leave.student.fullname}. Gate pass generated.")
    return redirect('leave_requests')


@warden_required
def leave_request_reject(request, lid):
    leave = get_object_or_404(LeaveRequest, id=lid)
    if request.method == 'POST':
        remark = request.POST.get('remark', '').strip()
        leave.status = 'Rejected'
        leave.warden_remark = remark
        leave.save()
        messages.success(request, f"Leave request rejected for "
                         f"{leave.student.fullname}.")
    return redirect('leave_requests')


# ---------------------------------------------------------------------------
# Warden: Room change requests
# ---------------------------------------------------------------------------
@warden_required
def room_change_requests(request):
    """Warden: list all room change AND swap requests, grouped by status.
    This is the unified 'Room Transfers' page for the warden."""
    # Room change (move) requests
    all_moves = RoomChangeRequest.objects.select_related(
        'student', 'student__room',
        'requested_room').order_by('-createdat')
    move_pending = [r for r in all_moves if r.status == 'Pending']
    move_approved = [r for r in all_moves if r.status == 'Approved']
    move_rejected = [r for r in all_moves if r.status == 'Rejected']
    # Room swap requests (only show those accepted by peer — awaiting warden)
    all_swaps = RoomSwapRequest.objects.select_related(
        'requester', 'requester__room',
        'target', 'target__room').order_by('-createdat')
    swap_pending = [s for s in all_swaps if s.status == 'Accepted by Peer']
    swap_approved = [s for s in all_swaps if s.status == 'Approved']
    swap_rejected = [s for s in all_swaps if 'Rejected' in s.status]
    context = {
        'warden_name': request.session.get('warden_name', 'Warden'),
        'move_pending': move_pending,
        'move_approved': move_approved,
        'move_rejected': move_rejected,
        'swap_pending': swap_pending,
        'swap_approved': swap_approved,
        'swap_rejected': swap_rejected,
    }
    return render(request, 'hostel/warden_room_change_requests.html', context)


@warden_required
def room_change_approve(request, rid):
    req = get_object_or_404(RoomChangeRequest, id=rid)
    if request.method == 'POST':
        remark = request.POST.get('remark', '').strip()
        # Check if the requested room still has space
        if req.requested_room.available <= 0:
            messages.error(request, f"Cannot approve — room "
                           f"{req.requested_room.roomnumber} is now full.")
            return redirect('room_change_requests')
        req.status = 'Approved'
        req.warden_remark = remark
        req.approved_at = timezone.now()
        # Actually move the student to the new room
        req.student.room = req.requested_room
        req.student.save()
        req.save()
        messages.success(request, f"Room change approved for "
                         f"{req.student.fullname}. Moved to room "
                         f"{req.requested_room.roomnumber}.")
    return redirect('room_change_requests')


@warden_required
def room_change_reject(request, rid):
    req = get_object_or_404(RoomChangeRequest, id=rid)
    if request.method == 'POST':
        remark = request.POST.get('remark', '').strip()
        req.status = 'Rejected'
        req.warden_remark = remark
        req.save()
        messages.success(request, f"Room change request rejected for "
                         f"{req.student.fullname}.")
    return redirect('room_change_requests')


# ---------------------------------------------------------------------------
# Warden: Room Swap approvals
# ---------------------------------------------------------------------------
@warden_required
def warden_room_swaps(request):
    """Warden: list all room swap requests, grouped by status."""
    all_swaps = RoomSwapRequest.objects.select_related(
        'requester', 'requester__room',
        'target', 'target__room').order_by('-createdat')
    pending = [s for s in all_swaps if s.status == 'Accepted by Peer']
    approved = [s for s in all_swaps if s.status == 'Approved']
    rejected = [s for s in all_swaps
                if 'Rejected' in s.status]
    context = {
        'warden_name': request.session.get('warden_name', 'Warden'),
        'pending': pending,
        'approved': approved,
        'rejected': rejected,
    }
    return render(request, 'hostel/warden_room_swaps.html', context)


@warden_required
def warden_room_swap_approve(request, sid):
    """Warden approves the swap — both students' rooms are exchanged."""
    swap = get_object_or_404(RoomSwapRequest, id=sid)
    if request.method == 'POST':
        remark = request.POST.get('remark', '').strip()
        if swap.status != 'Accepted by Peer':
            messages.error(request, "This swap request is not ready for "
                           "approval (peer hasn't accepted yet).")
            return redirect('warden_room_swaps')
        # Swap the rooms atomically
        requester_room = swap.requester.room
        target_room = swap.target.room
        swap.requester.room = target_room
        swap.target.room = requester_room
        swap.requester.save()
        swap.target.save()
        swap.status = 'Approved'
        swap.warden_remark = remark
        swap.approved_at = timezone.now()
        swap.save()
        messages.success(request, f"Room swap approved! "
                         f"{swap.requester.fullname} moved to Room "
                         f"{target_room.roomnumber}, "
                         f"{swap.target.fullname} moved to Room "
                         f"{requester_room.roomnumber}.")
    return redirect('warden_room_swaps')


@warden_required
def warden_room_swap_reject(request, sid):
    """Warden rejects the swap."""
    swap = get_object_or_404(RoomSwapRequest, id=sid)
    if request.method == 'POST':
        remark = request.POST.get('remark', '').strip()
        swap.status = 'Rejected by Warden'
        swap.warden_remark = remark
        swap.save()
        messages.success(request, f"Room swap rejected for "
                         f"{swap.requester.fullname} and "
                         f"{swap.target.fullname}.")
    return redirect('warden_room_swaps')
