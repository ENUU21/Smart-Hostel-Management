"""Context processor that adds pending request counts to every warden page,
so the sidebar badges show on all pages, not just the dashboard."""
from .models import LeaveRequest, RoomChangeRequest, RoomSwapRequest, Complaint


def warden_sidebar_counts(request):
    counts = {
        'sidebar_pending_leaves': 0,
        'sidebar_pending_room_changes': 0,
        'sidebar_pending_complaints': 0,
    }
    # Only compute if the warden is logged in
    if request.session.get('warden_id'):
        try:
            counts['sidebar_pending_leaves'] = LeaveRequest.objects.filter(
                status='Pending').count()
            # Room transfers = pending move requests + accepted-by-peer swaps
            move_pending = RoomChangeRequest.objects.filter(
                status='Pending').count()
            swap_pending = RoomSwapRequest.objects.filter(
                status='Accepted by Peer').count()
            counts['sidebar_pending_room_changes'] = move_pending + swap_pending
            counts['sidebar_pending_complaints'] = Complaint.objects.filter(
                status='Pending').count()
        except Exception:
            pass
    return counts
