"""Seed the database with a large set of demo data.

Generates:
  - 1 warden
  - 12 rooms (A01–A12), capacity 4 each
  - 50 students (5 named + 45 generated)
  - 20 complaints (varied titles, statuses, students)
  - 12 notices (varied titles and dates)
  - 8 leave requests (mixed pending/approved/rejected)
  - 5 room change requests (mixed pending/approved/rejected)
"""
import os
import random
from datetime import date, timedelta
import django

os.environ.setdefault('DJANGO_SETTINGS_MODULE', 'hostel_web.settings')
django.setup()

from hostel.models import (WardenUser, Room, Student, Complaint, Notice,
                           LeaveRequest, RoomChangeRequest)
from django.utils import timezone


def run():
    if WardenUser.objects.exists():
        print("Database already seeded. Skipping. "
              "(Delete db.sqlite3 to re-seed)")
        return

    random.seed(42)
    today = date.today()

    # ---- Warden ----
    WardenUser.objects.create(
        username='manash',
        password=WardenUser.hash_password('manash123'),
    )

    # ---- 15 rooms (capacity 4) — 3 extra so some rooms stay empty ----
    for n in range(1, 16):
        Room.objects.create(roomnumber=f'A{n:02d}', capacity=4)
    print(f"Created {Room.objects.count()} rooms (A01–A15, capacity 4)")

    # ---- 50 students (Indian boys names) ----
    # Strategy: fill rooms A01 → A15 in order, grouping same-year students
    # in the same room. Each room has capacity 4.
    # 5 years × ~10 students each = 50 students.
    # 2023 → A01, A02, A03 (10-12 students)
    # 2024 → A04, A05, A06 (10-12 students)
    # 2025 → A07, A08, A09 (10-12 students)
    # 2026 → A10, A11, A12 (10-12 students, includes named demo accounts)
    # 2027 → A13, A14, A15 (10-12 students)

    # Named demo accounts — all in year 2026, easy to remember logins
    named_students = [
        ('Arjun Sharma',    'arjun123',   'arjun123',   'arjun.sharma@hostel.edu',   '6371646323', 'Ramesh Sharma',  '9437012345'),
        ('Rahul Verma',     'rahul123',   'rahul123',   'rahul.verma@hostel.edu',    '6382383729', 'Suresh Verma',   '9437023456'),
        ('Vikram Patel',    'vikram123',  'vikram123',  'vikram.patel@hostel.edu',   '9876543210', 'Mahesh Patel',   '9437034567'),
        ('Rohit Singh',     'rohit123',   'rohit123',   'rohit.singh@hostel.edu',    '8765432109', 'Dinesh Singh',   '9437045678'),
        ('Aditya Kumar',    'aditya123',  'aditya123',  'aditya.kumar@hostel.edu',   '7654321098', 'Ganesh Kumar',   '9437056789'),
    ]

    # Indian boys first names
    first_names = [
        'Aarav', 'Vivaan', 'Aditya', 'Vihaan', 'Arjun', 'Sai', 'Reyansh',
        'Ayaan', 'Krishna', 'Ishaan', 'Rohan', 'Aryan', 'Kabir', 'Dhruv',
        'Karan', 'Rahul', 'Aakash', 'Nikhil', 'Varun', 'Pranav', 'Harsh',
        'Siddharth', 'Yash', 'Manav', 'Abhishek', 'Saurabh', 'Naman',
        'Prateek', 'Shubham', 'Dev', 'Tushar', 'Gaurav', 'Sandeep',
        'Akash', 'Vinay', 'Rajat', 'Piyush', 'Ankit', 'Sumeet', 'Rishi',
        'Tanish', 'Vedant', 'Laksh', 'Aadi', 'Naksh', 'Kiaan',
        'Rivaan', 'Shaurya', 'Atharva', 'Veer', 'Yug',
    ]
    last_names = [
        'Sharma', 'Verma', 'Patel', 'Singh', 'Kumar', 'Reddy', 'Nair',
        'Iyer', 'Menon', 'Gupta', 'Mehta', 'Joshi', 'Rao', 'Das', 'Bose',
        'Banerjee', 'Mishra', 'Agarwal', 'Kapoor', 'Khanna', 'Malhotra',
        'Chopra', 'Ghosh', 'Bhatt', 'Trivedi', 'Pandey', 'Yadav', 'Thakur',
        'Chaudhary', 'Pradhan', 'Mohanty', 'Nayak', 'Behera', 'Dash',
        'Mahapatra', 'Sahoo', 'Patnaik', 'Samal', 'Pillai', 'Shetty',
    ]
    guardian_first_names = [
        'Ramesh', 'Suresh', 'Mahesh', 'Dinesh', 'Ganesh', 'Prakash',
        'Vinod', 'Naresh', 'Rajesh', 'Mohan', 'Lal', 'Ram',
    ]

    # Build the full student list: 50 students across 5 years (10 per year)
    # Each year gets exactly 10 students. Named students are part of 2026.
    # Years are assigned so they fill rooms sequentially A01→A15.
    all_rooms = list(Room.objects.all().order_by('roomnumber'))
    room_idx = 0  # start filling from A01

    # Generate 45 random students (named 5 go into 2026)
    random_students = []
    used_usernames = set()
    for _ in range(45):
        while True:
            first = random.choice(first_names)
            last = random.choice(last_names)
            username = f'{first.lower()}{random.randint(100, 9999)}'
            if username not in used_usernames:
                used_usernames.add(username)
                break
        email = f'{first.lower()}.{last.lower()}@hostel.edu'
        phone = f'{random.choice("6789")}{random.randint(100000000, 999999999)}'
        g_first = random.choice(guardian_first_names)
        g_name = f'{g_first} {last}'
        g_phone = f'{random.choice("6789")}{random.randint(100000000, 999999999)}'
        random_students.append({
            'fullname': f'{first} {last}',
            'username': username,
            'email': email, 'phone': phone,
            'g_name': g_name, 'g_phone': g_phone,
        })

    # Distribute: 2023 → 10 random, 2024 → 10 random, 2025 → 10 random,
    # 2026 → 5 named + 5 random, 2027 → 10 random
    year_batches = {
        2023: random_students[0:10],
        2024: random_students[10:20],
        2025: random_students[20:30],
        2026: [],  # filled below with named + 5 random
        2027: random_students[35:45],
    }
    # 2026 batch: 5 named students + 5 random (indices 30-34)
    for ns in named_students:
        year_batches[2026].append({
            'fullname': ns[0], 'username': ns[1], 'pw': ns[2],
            'email': ns[3], 'phone': ns[4],
            'g_name': ns[5], 'g_phone': ns[6],
        })
    for rs in random_students[30:35]:
        rs['pw'] = rs['username']  # password = username for demo
        year_batches[2026].append(rs)

    # Now assign rooms: fill A01 first, same year in same room(s)
    for year in [2023, 2024, 2025, 2026, 2027]:
        batch = year_batches[year]
        batch_idx = 0
        while batch_idx < len(batch):
            # Find next room with space
            while room_idx < len(all_rooms) and all_rooms[room_idx].available <= 0:
                room_idx += 1
            if room_idx >= len(all_rooms):
                break  # all rooms full
            room = all_rooms[room_idx]
            # Fill this room with students from this batch (up to capacity)
            slots = room.available
            for _ in range(slots):
                if batch_idx >= len(batch):
                    break
                s = batch[batch_idx]
                pw = s.get('pw', s['username'])
                Student.objects.create(
                    fullname=s['fullname'], username=s['username'],
                    password=Student.hash_password(pw),
                    email=s['email'], phone=s['phone'], room=room,
                    guardian_name=s['g_name'], guardian_phone=s['g_phone'],
                    academic_year=year,
                )
                batch_idx += 1
            room_idx += 1
    print(f"Created {Student.objects.count()} students")

    # ---- 20 complaints ----
    complaint_templates = [
        ('Fan not working',
         'The ceiling fan in my room has stopped working.'),
        ('Light bulb broken',
         'The tube light in my room is flickering and sometimes goes off.'),
        ('Water supply issue',
         'There is no water supply in our bathroom since morning.'),
        ('Wi-Fi not working',
         'The hostel Wi-Fi is very slow and keeps disconnecting.'),
        ('Room door lock jammed',
         'The door lock of my room is jammed and I cannot lock it properly.'),
        ('Dirty bathroom',
         'The common bathroom on our floor has not been cleaned for days.'),
        ('Mosquito problem',
         'There are a lot of mosquitoes in my room.'),
        ('Broken study table',
         'The study table in my room has a broken leg and wobbles.'),
        ('Geyser not heating',
         'The water geyser is not heating the water at all.'),
        ('Noisy neighbours',
         'The students in the adjacent room play loud music late at night.'),
        ('Window pane cracked',
         'The glass pane of my window is cracked.'),
        ('Electric socket broken',
         'One of the electric sockets in my room is not working.'),
        ('Drainage blockage',
         'The drain in our washroom is blocked and water is overflowing.'),
        ('Cockroach infestation',
         'There are cockroaches in my room and the kitchen area.'),
        ('Broken chair',
         'The chair in my room is broken and I almost fell.'),
        ('No hot water in morning',
         'There is no hot water available in the morning for bathing.'),
        ('Wall paint peeling',
         'The paint on the wall near my bed is peeling off.'),
        ('Intercom not working',
         'The intercom in my room is dead.'),
        ('Curtain rod loose',
         'The curtain rod in my room is loose and about to fall.'),
        ('Water cooler not cooling',
         'The water cooler on our floor is not cooling the water.'),
    ]
    students = list(Student.objects.all())
    statuses = ['Pending'] * 8 + ['In Progress'] * 7 + ['Resolved'] * 5
    random.shuffle(statuses)
    now = timezone.now()
    for i, (title, desc) in enumerate(complaint_templates):
        student = random.choice(students)
        status = statuses[i % len(statuses)]
        days_ago = random.randint(0, 30)
        created_time = now - timedelta(days=days_ago, hours=random.randint(0, 23))
        c = Complaint.objects.create(
            student=student, title=title, description=desc, status=status,
        )
        Complaint.objects.filter(id=c.id).update(createdat=created_time)
    print(f"Created {Complaint.objects.count()} complaints")

    # ---- 12 notices ----
    notice_templates = [
        ('Hostel Mess Timing Change',
         'All students are informed that the hostel mess will remain closed '
         'on Sundays for cleaning. Please plan your meals accordingly.'),
        ('Wi-Fi Maintenance',
         'Internet will be unavailable on Saturday 2 AM - 4 AM due to '
         'scheduled maintenance.'),
        ('Hostel Fee Payment Reminder',
         'This is a reminder that the hostel fee for the current semester '
         'is due by the end of this month.'),
        ('Annual Sports Day Registration',
         'Registration for the Annual Sports Day is now open. Interested '
         'students can sign up at the sports office.'),
        ('Water Supply Disruption',
         'There will be a temporary water supply disruption tomorrow from '
         '10 AM to 2 PM due to tank cleaning.'),
        ('Curfew Timing Update',
         'The hostel curfew timing has been revised. Students must return '
         'to the hostel by 9:30 PM on weekdays.'),
        ('Room Inspection Notice',
         'A surprise room inspection will be conducted this week. Students '
         'are advised to keep their rooms clean.'),
        ('Medical Camp on Campus',
         'A free medical checkup camp will be organized in the hostel common '
         'room this Saturday from 9 AM to 1 PM.'),
        ('Library Book Return Reminder',
         'Students who have borrowed books from the hostel library are '
         'requested to return them before the semester ends.'),
        ('Festival Celebration',
         'The hostel committee is organizing a cultural night to celebrate '
         'the upcoming festival.'),
        ('Fire Safety Drill',
         'A fire safety drill will be conducted next Monday at 5 PM. All '
         'students must participate.'),
        ('Hostel Renovation Update',
         'Renovation work on the second floor will begin next month.'),
    ]
    for i, (title, desc) in enumerate(notice_templates):
        days_ago = random.randint(0, 45)
        created_time = now - timedelta(days=days_ago, hours=random.randint(0, 23))
        n = Notice.objects.create(title=title, description=desc)
        Notice.objects.filter(id=n.id).update(createdat=created_time)
    print(f"Created {Notice.objects.count()} notices")

    # ---- 8 leave requests ----
    leave_data = [
        # (student_index, from_offset, to_offset, destination, reason, status)
        (0, 5, 8, 'Home — Bhubaneswar',
         'Going home for a family function this weekend.', 'Pending'),
        (1, 3, 6, 'Home — Cuttack',
         'Need to visit home for a medical checkup.', 'Pending'),
        (2, 1, 4, 'Relative\'s place — Kolkata',
         'Attending a wedding in the family.', 'Pending'),
        (3, 7, 12, 'Home — Rourkela',
         'Going home for the weekend break.', 'Pending'),
        (4, -2, 2, 'Home — Puri',
         'Family emergency — need to visit home urgently.',
         'Approved'),
        (5, -5, -1, 'Home — Sambalpur',
         'Festival at home — want to spend time with family.',
         'Approved'),
        (6, -3, -1, 'Friend\'s place — Berhampur',
         'Attending a friend\'s birthday celebration.', 'Rejected'),
        (7, -1, 3, 'Home — Balasore',
         'Not feeling well — going home to rest.', 'Pending'),
    ]
    all_students = list(Student.objects.all())
    for idx, from_off, to_off, dest, reason, status in leave_data:
        if idx >= len(all_students):
            continue
        student = all_students[idx]
        from_date = today + timedelta(days=from_off)
        to_date = today + timedelta(days=to_off)
        lr = LeaveRequest.objects.create(
            student=student, from_date=from_date, to_date=to_date,
            destination=dest, reason=reason, status=status,
            warden_remark=('Approved. Please collect your gate pass.'
                           if status == 'Approved'
                           else ('Not enough notice. Please apply '
                                 'at least 3 days in advance.'
                                 if status == 'Rejected' else '')),
        )
        if status == 'Approved':
            lr.approved_at = now - timedelta(days=1)
            lr.save()
    print(f"Created {LeaveRequest.objects.count()} leave requests")

    # ---- 5 room change requests ----
    room_change_data = [
        (0, 5, 'Want to move closer to my friend for group study.',
         'Pending'),
        (1, 7, 'My current room is too noisy. Need a quieter room.',
         'Pending'),
        (2, 3, 'Want to share a room with my classmate.',
         'Pending'),
        (3, 9, 'Medical reason — need a ground floor room.',
         'Approved'),
        (4, 11, 'Want a room with better ventilation.',
         'Rejected'),
    ]
    for idx, room_idx, reason, status in room_change_data:
        if idx >= len(all_students):
            continue
        student = all_students[idx]
        target_room = Room.objects.get(id=room_idx)
        rcr = RoomChangeRequest.objects.create(
            student=student, requested_room=target_room, reason=reason,
            status=status,
            warden_remark=('Approved and moved.' if status == 'Approved'
                           else ('No rooms available in that block.'
                                 if status == 'Rejected' else '')),
        )
        if status == 'Approved':
            rcr.approved_at = now - timedelta(days=2)
            rcr.save()
    print(f"Created {RoomChangeRequest.objects.count()} room change requests")

    print("\n=== Seed complete ===")
    print(f"  Warden:           1 (manash / manash123)")
    print(f"  Rooms:            {Room.objects.count()}")
    print(f"  Students:         {Student.objects.count()}")
    print(f"  Complaints:       {Complaint.objects.count()}")
    print(f"  Notices:          {Notice.objects.count()}")
    print(f"  Leave requests:   {LeaveRequest.objects.count()}")
    print(f"  Room changes:     {RoomChangeRequest.objects.count()}")
    print(f"\n  Demo logins: pradip123/pradip123, kunu123/kunu123, ...")


if __name__ == '__main__':
    run()
